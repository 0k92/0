import "./scss/pages/client.scss";

import "./scripts/main";
import "./scripts/ui";
import "./scripts/news/newsWidget";
