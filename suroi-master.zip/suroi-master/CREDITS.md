# Credits

## Developers
- Henry Sanger \(https://github.com/hsanger)
- Damien Vesper \(https://github.com/DamienVesper)
- Leo \(https://github.com/leo78913)
- Radians \(https://github.com/rsgtree)
- Katloo \(https://github.com/Katloo24)

## Artists
- Asultra
- Henry Sanger \(https://github.com/hsanger)
- Leo \(https://github.com/leo78913)
- SquareCube
- DogEnjoyer
- Dachselt
- canva.com

## Sound designers
- Katloo \(https://github.com/Katloo24)
- TTGetDunkedOn
